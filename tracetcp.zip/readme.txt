tracetcp (c) 2003 L.M.Witek

http://sourceforge.net/projects/tracetcp/

Description
===========

tracetcp is a traceroute utility for WIN32 that uses TCP SYN packets rather
than ICMP/UDP packets that the usual implementations use, thus bypassing
gateways that block traditional traceroute packets.

In addition to providing the functionality of the standard traceroute
utility tracetcp allows a trace to be performed over any TCP port. This
allows the discovery of what ports a filewall blocks & and also the presence
of any transparent proxies that have been put in place.

Requirements
============

tracetcp uses Winsock Raw sockets, and as such, only runs on Windows 2000 &
XP (It also probably runs on Windows 2003 but has not been tested on this
platform). You must be logged on to the System as a user that has
administrator rights to use tracetcp. 

Note: tracetcp will not work on Windows NT4, 95, 98 or ME.

Also, I have noticed that tracetcp does no work with ZoneAlarm installed as 
ZA seems to be blocking the returned packets. It works OK with XP's built-in
filewall though. I will investigate this further. 


Installation
============

Just copy tracetcp.exe into a directory that is in you system PATH.

Usage
=====

From the command prompt:

tracetcp host [options]
    where host = hostName|ipAddress[:portNumber|serviceName]
    if portNumber or serviceName is not present then port 80 (http) 
    is assumed.

Options:
    -?            Displays help information.
    -c            Select condensed output mode
    -h start_hop  Starts trace at hop specified.
    -m max_hops   Maximum number of hops to reach target.
    -n            No reverse DNS lookups for each node.
    -p num_pings  # of pings per hop (default 3).
    -r p1 p2      Multiple traces from port p1 to p2.
    -t timeout    Wait timeout milliseconds for each reply.
    -v            Displays version information.

Examples:
    tracetcp www.microsoft.com:80 -m 60
    tracetcp post.sponge.com:smtp
    tracetcp 192.168.0.1 -n -t 500


Compiling the source
====================

tracetcp is built with Visual Studio .NET 2003. It may be possible to use
older versions of Visual Studio to build tracetcp, but I have not tried
this.

If you require to rebuild tracetcp from the source then either download the
source distribution from sourceforge or get the latest files from the CVS
archive. (see the sourceforge documentation for help on getting read only
access to the CVS archive)

Visual Studio project files now included in source archive so you van load 
the project: tracetcp.vcproj and build within the IDE.

There is also a build.bat file include with the source that will create the
executable. To use the build.bat file you may need to edit the sdkvars.bat 
to set the PATH, LIB, & INCLUDE Environment variables to refer to your 
installation of Visual Studio. 

At some point I will include a makefile.

Revision History
================

version 0.99.1 beta 25-08-2003
    *Added start hop option (-h) and changed help to -?
    *Added port range option -r to allow port scanning
    *Separated Tracing code and results display so that different 
     display formats can be supported.
    *Added Condensed output mode (-c)
    *Added pings per hop option (-p)
    *Fixed a few Problems with the way packets were built
    *Visual Studio project files now included in source archive

version 0.99beta 19-08-2003
    First release on sourceforge.

version 0.90beta 21-07-2003
    Internal test version.




